import numpy as np
import cv2
import tkinter as tk
from tkinter import *

def opencctv_cameras():
    def cam_start():
        cap = cv2.VideoCapture(0)

        while (True):
            # Capture frame-by-frame
            ret, frame = cap.read()

            # Our operations on the frame come here
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Display the resulting frame
            cv2.imshow('Camera 1', gray)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # When everything done, release the capture
        cap.release()
        cv2.destroyAllWindows()

    cam = Tk()
    cam.geometry("250x250")
    cam.title("Hospital management system")
    b1 = tk.Button(cam , text="start" ,command=cam_start)
    b1.place(x=100,y=100)
    l1=tk.Label(cam, text="Press q to stop camera" , fg="red")
    l1.place(x=60,y=60)
    b2 = tk.Button(cam, text="Back", command=cam.destroy)
    b2.place(x=100, y=140)

    cam.mainloop()

opencctv_cameras()